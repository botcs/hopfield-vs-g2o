/***************************************************************
 * Name:      wxkitApp.h
 * Purpose:   Defines Application Class
 * Author:     ()
 * Created:   2016-12-31
 * Copyright:  ()
 * License:
 **************************************************************/

#ifndef WXKITAPP_H
#define WXKITAPP_H

#include <wx/app.h>

class wxkitApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // WXKITAPP_H
